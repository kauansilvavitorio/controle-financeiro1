import FinanceDashboard from "./FinanceDashboard";

export default function App() {
  return <FinanceDashboard />;
}
